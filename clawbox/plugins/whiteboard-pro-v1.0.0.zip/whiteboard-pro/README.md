# 白板 Pro

> AI Agent 团队的作战地图
> 定价: ¥79

## 功能

- multi-project management
- state.json CLI
- changelog
- phase gate
- experience database
- context injection
- cross-platform CLI
- patrol watchdog
- alerts
- audit log

## 安装

macOS / Linux: node install.js
Windows: 双击 install.bat

## 激活

安装后运行: fairy license
获取授权码后: fairy license WHITEBOARD-PRO-XXXX-XXXX-XXXX

## 使用

  fairy status              # 查看项目状态
  fairy log "完成功能"      # 记录变更
  fairy lesson 主题 详情     # 记经验
  fairy chain-check          # 检查门禁
  fairy update-agent dev running  # 更新进度

---
Version 1.0.0 | 跨平台: macOS / Linux / Windows